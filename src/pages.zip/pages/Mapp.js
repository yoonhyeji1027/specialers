import React, { useEffect } from 'react';
import "./Map.css";
import NavBar from './NavBar';
import { Map, MapMarker } from 'react-kakao-maps-sdk';

export default function Mapp() {
    {/* useEffect(() => {
        const script = document.createElement('script');
        script.type = 'text/javascript';
        script.src = '//dapi.kakao.com/v2/maps/sdk.js?appkey=a4b9e3dd536fa0de70d6353cfa92ce39';
        script.async = true;
        script.onload = () => {
            // 지도 스크립트가 로드된 후에 실행될 내용
        };
        document.body.appendChild(script);

        return () => {
            document.body.removeChild(script);
        };
    }, []);
*/}

    return (
        <div className='table-container'>  {/* 반응형 웹 구현때문에 설정해뒀던 클래스명임 */}
            <table>
                <NavBar /> {/*메인 페이지랑 텍스트 색이 달라서 각 페이지에 따로 추가*/}
                <div className="map"> {/*지도 관련 코드 */}
                    <h1 style={{ color: '#4D606B' }}>오시는 길</h1>
                    <hr />
                    <iframe
                        src="https://www.google.co.kr/maps/place/%EA%B0%95%EC%9B%90%EB%8F%84+%EC%96%91%EC%96%91%EA%B5%B0+%EC%86%90%EC%96%91%EB%A9%B4+%ED%95%99%ED%8F%AC%EA%B8%B8+226-26/data=!3m1!4b1!4m6!3m5!1s0x5fd8aea6b382dfff:0x52decf6e1b75e4b9!8m2!3d38.0744547!4d128.6511204!16s%2Fg%2F11bzmy7fxz?hl=ko&entry=ttu"
                        width="969px"
                        height="467px"
                        style={{ border: '0' }}
                        allowFullScreen=""
                        loading="lazy"
                        referrerPolicy="no-referrer-when-downgrade"
                    ></iframe>
                    {/* <Map 
                    center={{ lat: 33.5563, lng: 126.79581 }}   // 지도의 중심 좌표
                    style={{ width: '800px', height: '600px' }} // 지도 크기
                    level={3}                                   // 지도 확대 레벨
                >
                    <MapMarker position={{ lat: 33.55635, lng: 126.795841 }}> </MapMarker>  
    </Map> */}
                </div>

                <div className="map_info"> {/*주소 및 회사 연락처 */}
                    <hr style={{ borderStyle: 'dotted', padding: '0px 250px' }} />
                    <ul id="map_info_text">
                        <li style={{ fontSize: '20px' }}><h3>주소</h3><br />강원특별자치도 양양군 손양면 학포길 226-61</li>
                        <li style={{ fontSize: '20px' }}><h3>TEL</h3><br />010-1111-1234</li>
                        <li style={{ fontSize: '20px' }}><h3>FAX</h3><br />0000-000-1234</li>
                    </ul>
                </div>


                <footer>
                    <nav> {/* 푸터에서 각 페이지로 이동할 링크 리스트들 */}
                        <a href="S_info.js" className="footer_link">회사소개</a>
                        <a href="J_info.js" className="footer_link">제품소개</a>
                        <a href="SalmonPage.js" className="footer_link">연어양식</a>
                        <a href="Map.js" className="footer_link">오시는길</a>
                    </nav>
                    <address> {/* 링크가 필요 없는 주소 */}
                        <p>(주) 스페셜러스</p>
                        <p>주소: 강원특별자치도 양양군 손양면 학포길 226-61</p>
                        <p>©2023 specialers Corporation ALL RIGHTS RESERVED</p>
                    </address>
                </footer>

            </table>

        </div>
    );
}
